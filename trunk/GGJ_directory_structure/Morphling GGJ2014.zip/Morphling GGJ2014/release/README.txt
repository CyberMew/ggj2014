Morphing is a 2D topdown action game where the gameplay is dependant on the choices that the player makes.
Choose to either shoot or collect the initial question blobs to select the type of mini game that you will play.
Collect them all? Play an exciting variant of the classic Snake!
Shoot them down instead? Welcome to a fast-paced arena shooter!
Perform both actions? Enjoy a wonderful hybrid between the two different genres!
The choice is yours in Morphing!