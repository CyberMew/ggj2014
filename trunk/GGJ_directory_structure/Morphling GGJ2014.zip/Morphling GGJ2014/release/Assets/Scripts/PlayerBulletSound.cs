﻿using UnityEngine;
using System.Collections;

public class PlayerBulletSound : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
		audio.Play ();
	}

}
