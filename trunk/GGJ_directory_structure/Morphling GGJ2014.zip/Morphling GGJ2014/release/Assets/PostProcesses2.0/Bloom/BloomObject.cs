using UnityEngine;
using System.Collections;

public class BloomObject : MonoBehaviour 
{
	
	public Color BloomColor = Color.white;


}
