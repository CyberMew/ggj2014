﻿using UnityEngine;
using System.Collections;

public class FaceForward : MonoBehaviour {
	private Vector3 dirVec = new Vector3();
	private float angleRad = 0f;

	// Use this for initialization
	void Start () {
		dirVec = Vector3.Cross (transform.up, transform.forward);
		angleRad = Mathf.Atan2(dirVec.y, dirVec.x);		
	}
	
	// Update is called once per frame
	void Update () {
		dirVec = Vector3.Cross (transform.up, transform.forward);
		angleRad = Mathf.Atan2(dirVec.y, dirVec.x);
	}

	void InterpolateToAngle()
	{

	}

	void OnDestroy()
	{
		CancelInvoke();
	}
}
